Arcade: Centipede port to MiST by Gehstock

24 November 2018
-- 
-- 

	Only controls and OSD are rotated on Video output. 

	Keyboard inputs :

		ESC        : Coin/Start Player
--   
		SPACE 	: Fire or Fire Button
--   
		ARROW KEYS : Movements