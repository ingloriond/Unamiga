#ifndef _LS_HELP_H
#define _LS_HELP_H

extern unsigned char ls_help[];
extern unsigned char ls_version[];

#endif
