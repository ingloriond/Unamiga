#ifndef PATH_H
#define PATH_H

extern char *path_open(void);
extern char *path_next(void);
extern void path_close(void);

#endif
