/src/ folder contents
---------------------

/src/asm/ Z80(n) Assembler sources
/src/bas/ NextBASIC sources
/src/c/   C sources

Source code contained in the folders above may come in a variety of licenses
by its respective authors. Please observe each license in kind.

There are also two special folders:

/src/firmware/ contains the c sources of the current FW file
/src/vhdl/ contains the VHDL sources of the current core

Both of the latter are released under GPL v.3 however sources may 
lag a bit behind for the distribution as they need to be vetted before 
uploaded.