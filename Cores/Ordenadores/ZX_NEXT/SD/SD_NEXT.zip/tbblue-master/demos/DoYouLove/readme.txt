Next version of my Do you love? rolling demo 

original song fleetwood mac
tuned by emook
images courtesy of the google search
other code by emook 

uses boriel zx basic compiler <3

